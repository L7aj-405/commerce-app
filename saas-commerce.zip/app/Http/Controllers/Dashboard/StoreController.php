<?php

declare(strict_types=1);

namespace App\Http\Controllers\Dashboard;

use App\Enums\StoreStatus;
use App\Enums\StoreType;
use App\Http\Controllers\Controller;
use App\Models\Store;
use App\Models\StoreMember;
use App\Services\OrganizationProvisioner;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Inertia\Inertia;
use Inertia\Response;

// Edit/Update/Destroy methods appended at end

class StoreController extends Controller
{
    public function index(Request $request): Response
    {
        $user = $request->user();

        $stores = $user->accessibleStores()
            ->filter(fn (Store $store) => $user->hasStorePermission($store, 'stores.manage'))
            ->map(function (Store $store): array {
                $store->loadCount('activeMembers as member_count');

                return [
                    'id' => $store->id,
                    'name' => $store->name,
                    'type' => $store->type,
                    'business_type' => $store->business_type,
                    'country' => $store->country,
                    'currency' => $store->currency,
                    'status' => $store->status,
                    'logo' => $store->logo,
                    'member_count' => $store->member_count,
                ];
            })
            ->sortBy('name')
            ->values();

        $currentStoreId = $user->getActiveStore()?->id;

        return Inertia::render('Dashboard/Stores/Index', [
            'stores'         => $stores,
            'currentStoreId' => $currentStoreId,
        ]);
    }

    public function create(): Response
    {
        return Inertia::render('Dashboard/Stores/Create', [
            'businessTypes' => [
                ['value' => 'retail',      'label' => 'Retail Store'],
                ['value' => 'restaurant',  'label' => 'Restaurant / Café'],
                ['value' => 'fashion',     'label' => 'Clothing & Fashion'],
                ['value' => 'electronics', 'label' => 'Electronics'],
                ['value' => 'grocery',     'label' => 'Grocery'],
                ['value' => 'other',       'label' => 'Other'],
            ],
            'countries' => [
                ['code' => 'US', 'name' => 'United States',  'currency' => 'USD'],
                ['code' => 'CA', 'name' => 'Canada',         'currency' => 'CAD'],
                ['code' => 'GB', 'name' => 'United Kingdom', 'currency' => 'GBP'],
                ['code' => 'FR', 'name' => 'France',         'currency' => 'EUR'],
                ['code' => 'MA', 'name' => 'Morocco',        'currency' => 'MAD'],
                ['code' => 'DZ', 'name' => 'Algeria',        'currency' => 'DZD'],
                ['code' => 'TN', 'name' => 'Tunisia',        'currency' => 'TND'],
                ['code' => 'AE', 'name' => 'UAE',            'currency' => 'AED'],
            ],
        ]);
    }

    public function store(Request $request, OrganizationProvisioner $organizations): RedirectResponse
    {
        $validated = $request->validate([
            'store_name'    => ['required', 'string', 'max:255'],
            'business_type' => ['required', 'in:retail,restaurant,fashion,electronics,grocery,other'],
            'country'       => ['required', 'string', 'size:2'],
            'currency'      => ['required', 'string', 'size:3'],
            'phone'         => ['nullable', 'string', 'max:50'],
        ]);

        $user = $request->user();

        $store = DB::transaction(function () use ($user, $validated, $organizations) {
            $organization = $organizations->forNewStore($user, $validated['store_name']);

            $store = Store::create([
                'organization_id' => $organization->id,
                'user_id'       => $user->id,
                'name'          => $validated['store_name'],
                'slug'          => Str::slug($validated['store_name']) . '-' . Str::lower(Str::random(4)),
                'type'          => StoreType::Online->value,
                'business_type' => $validated['business_type'],
                'country'       => $validated['country'],
                'currency'      => $validated['currency'],
                'phone'         => $validated['phone'] ?? null,
                'status'        => StoreStatus::Active->value,
                'settings'      => ['tax_rate' => 0, 'timezone' => 'UTC'],
            ]);

            $store->ensureDefaultRoles();

            StoreMember::create([
                'store_id'      => $store->id,
                'user_id'       => $user->id,
                'role'          => 'store_admin',
                'store_role_id' => $store->adminRole()?->id,
                'is_active'     => true,
                'joined_at'     => now(),
            ]);

            return $store;
        });

        $request->session()->put('store_id', $store->id);

        return redirect()->route('dashboard.stores.index')->with('success', "Store \"{$store->name}\" created.");
    }

    public function edit(Request $request, Store $store): Response
    {
        abort_unless($request->user()->hasStorePermission($store, 'stores.manage'), 403);

        return Inertia::render('Dashboard/Stores/Edit', [
            'store' => $store->only(['id', 'name', 'business_type', 'country', 'currency', 'phone', 'settings']),
            'businessTypes' => [
                ['value' => 'retail',      'label' => 'Retail Store'],
                ['value' => 'restaurant',  'label' => 'Restaurant / Café'],
                ['value' => 'fashion',     'label' => 'Clothing & Fashion'],
                ['value' => 'electronics', 'label' => 'Electronics'],
                ['value' => 'grocery',     'label' => 'Grocery'],
                ['value' => 'other',       'label' => 'Other'],
            ],
        ]);
    }

    public function update(Request $request, Store $store): RedirectResponse
    {
        abort_unless($request->user()->hasStorePermission($store, 'stores.manage'), 403);

        $validated = $request->validate([
            'name'          => ['required', 'string', 'max:255'],
            'business_type' => ['nullable', 'string'],
            'country'       => ['nullable', 'string', 'size:2'],
            'currency'      => ['nullable', 'string', 'size:3'],
            'phone'         => ['nullable', 'string', 'max:50'],
        ]);

        $store->update($validated);

        return back()->with('success', 'Store updated.');
    }

    public function destroy(Request $request, Store $store): RedirectResponse
    {
        abort_unless($request->user()->hasStorePermission($store, 'stores.manage'), 403);

        $store->delete();

        return redirect()->route('dashboard.stores.index')->with('success', 'Store deleted.');
    }
}

<?php

declare(strict_types=1);

namespace App\Services\Shopify;

use RuntimeException;

class ShopifyAuthException extends RuntimeException
{
}

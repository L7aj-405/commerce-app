import { Link, useForm } from '@inertiajs/react';
import { ArrowLeft, Loader2, Store as StoreIcon, Globe, Phone, Briefcase } from 'lucide-react';
import SaasLayout from '@/Layouts/SaasLayout';

export default function Create({ businessTypes = [], countries = [] }) {
    const { data, setData, post, processing, errors } = useForm({
        store_name:    '',
        business_type: '',
        country:       countries[0]?.code ?? '',
        currency:      countries[0]?.currency ?? '',
        phone:         '',
    });

    const onCountryChange = (code) => {
        const c = countries.find((c) => c.code === code);
        setData((d) => ({ ...d, country: code, currency: c?.currency ?? d.currency }));
    };

    const submit = (e) => {
        e.preventDefault();
        post('/dashboard/stores');
    };

    return (
        <SaasLayout pageHeader={{
            title: 'Add a store',
            subtitle: 'You can run multiple stores from a single account.',
            breadcrumbs: [
                { label: 'Dashboard', href: '/dashboard' },
                { label: 'Stores',    href: '/dashboard/stores' },
                { label: 'Add' },
            ],
            actions: (
                <Link
                    href="/dashboard/stores"
                    className="inline-flex items-center gap-1.5 px-3 py-2 text-sm font-medium rounded-lg bg-surface-2 border border-line text-content-muted hover:bg-surface-3 hover:text-content"
                >
                    <ArrowLeft className="w-4 h-4" /> Back
                </Link>
            ),
        }}>
            <form onSubmit={submit} className="max-w-2xl space-y-5">
                <Field
                    label="Store name"
                    icon={StoreIcon}
                    value={data.store_name}
                    onChange={(v) => setData('store_name', v)}
                    error={errors.store_name}
                    required
                />

                <Select
                    label="Business type"
                    icon={Briefcase}
                    value={data.business_type}
                    onChange={(v) => setData('business_type', v)}
                    options={businessTypes}
                    placeholder="Choose your industry"
                    error={errors.business_type}
                    required
                />

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Select
                        label="Country"
                        icon={Globe}
                        value={data.country}
                        onChange={onCountryChange}
                        options={countries.map((c) => ({ value: c.code, label: c.name }))}
                        placeholder="Choose your country"
                        error={errors.country}
                        required
                    />
                    <Field
                        label="Currency"
                        value={data.currency}
                        onChange={(v) => setData('currency', v.toUpperCase().slice(0, 3))}
                        error={errors.currency}
                        required
                    />
                </div>

                <Field
                    label="Phone (optional)"
                    icon={Phone}
                    type="tel"
                    value={data.phone}
                    onChange={(v) => setData('phone', v)}
                    error={errors.phone}
                />

                <div className="pt-2">
                    <button
                        type="submit"
                        disabled={processing}
                        className="inline-flex items-center gap-1.5 px-5 py-2.5 text-sm font-semibold rounded-lg bg-indigo-600 text-white hover:bg-indigo-500 disabled:opacity-50 transition"
                    >
                        {processing ? <><Loader2 className="w-4 h-4 animate-spin" /> Creating…</> : 'Create store'}
                    </button>
                </div>
            </form>
        </SaasLayout>
    );
}

function Field({ label, icon: Icon, type = 'text', value, onChange, error, required }) {
    return (
        <div>
            <label className="block text-sm font-medium text-content-muted mb-1">
                {label} {required && <span className="text-red-600 dark:text-red-400">*</span>}
            </label>
            <div className="relative">
                {Icon && <Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-content-muted pointer-events-none" />}
                <input
                    type={type}
                    value={value}
                    onChange={(e) => onChange(e.target.value)}
                    className={`w-full ${Icon ? 'pl-9' : 'pl-3'} pr-3 py-2 rounded-lg bg-surface-3 border ${
                        error ? 'border-red-500' : 'border-line'
                    } text-content focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent`}
                />
            </div>
            {error && <p className="mt-1 text-xs text-red-600 dark:text-red-400">{error}</p>}
        </div>
    );
}

function Select({ label, icon: Icon, value, onChange, options, placeholder, error, required }) {
    return (
        <div>
            <label className="block text-sm font-medium text-content-muted mb-1">
                {label} {required && <span className="text-red-600 dark:text-red-400">*</span>}
            </label>
            <div className="relative">
                {Icon && <Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-content-muted pointer-events-none" />}
                <select
                    value={value}
                    onChange={(e) => onChange(e.target.value)}
                    className={`w-full ${Icon ? 'pl-9' : 'pl-3'} pr-3 py-2 rounded-lg bg-surface-3 border ${
                        error ? 'border-red-500' : 'border-line'
                    } text-content focus:outline-none focus:ring-2 focus:ring-indigo-500`}
                >
                    {placeholder && <option value="">{placeholder}</option>}
                    {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
                </select>
            </div>
            {error && <p className="mt-1 text-xs text-red-600 dark:text-red-400">{error}</p>}
        </div>
    );
}

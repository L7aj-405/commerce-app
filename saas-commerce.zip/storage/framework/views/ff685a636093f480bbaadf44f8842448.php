<?php ($store = $facture->store); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: dejavusans, sans-serif; color: #1a1a1a; font-size: 12px; }
        .header { width: 100%; margin-bottom: 24px; }
        .header td { vertical-align: top; }
        .brand { font-size: 20px; font-weight: bold; color: #4f46e5; }
        .muted { color: #6b7280; }
        h1 { font-size: 22px; margin: 0; letter-spacing: 1px; }
        .meta td { padding: 2px 0; }
        table.items { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table.items th { background: #f3f4f6; text-align: left; padding: 8px; font-size: 11px; text-transform: uppercase; color: #374151; }
        table.items td { padding: 8px; border-bottom: 1px solid #e5e7eb; }
        .right { text-align: right; }
        .totals { width: 40%; margin-left: 60%; margin-top: 16px; }
        .totals td { padding: 4px 8px; }
        .totals .grand { font-size: 15px; font-weight: bold; border-top: 2px solid #111827; }
        .status { display: inline-block; padding: 3px 10px; border-radius: 4px; font-size: 11px; font-weight: bold; text-transform: uppercase; }
        .status-paid { background: #d1fae5; color: #065f46; }
        .status-other { background: #e0e7ff; color: #3730a3; }
        .footer { margin-top: 40px; font-size: 10px; color: #9ca3af; text-align: center; }
    </style>
</head>
<body>
    <table class="header">
        <tr>
            <td style="width:60%">
                <div class="brand"><?php echo e($store->name); ?></div>
                <div class="muted"><?php echo e($store->address); ?></div>
                <div class="muted"><?php echo e($store->email); ?> · <?php echo e($store->phone); ?></div>
            </td>
            <td style="width:40%" class="right">
                <h1>INVOICE</h1>
                <div class="muted"><?php echo e($facture->invoice_number); ?></div>
                <span class="status <?php echo e($facture->status === 'paid' ? 'status-paid' : 'status-other'); ?>"><?php echo e($facture->status); ?></span>
            </td>
        </tr>
    </table>

    <table class="meta" style="width:100%">
        <tr>
            <td style="width:60%">
                <strong>Bill To</strong><br>
                <?php echo e($facture->customer_name); ?><br>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($facture->customer_email): ?><?php echo e($facture->customer_email); ?><br><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($facture->customer_phone): ?><?php echo e($facture->customer_phone); ?><br><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php echo e($facture->customer_address); ?>

            </td>
            <td style="width:40%" class="right">
                <strong>Invoice date:</strong> <?php echo e($facture->invoice_date?->format('Y-m-d')); ?><br>
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($facture->due_date): ?><strong>Due date:</strong> <?php echo e($facture->due_date->format('Y-m-d')); ?><br><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <strong>Payment:</strong> <?php echo e(ucfirst($facture->payment_method)); ?>

            </td>
        </tr>
    </table>

    <table class="items">
        <thead>
            <tr>
                <th>Description</th>
                <th class="right">Qty</th>
                <th class="right">Unit price</th>
                <th class="right">Line total</th>
            </tr>
        </thead>
        <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $facture->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->description); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->sku): ?><br><span class="muted"><?php echo e($item->sku); ?></span><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?></td>
                    <td class="right"><?php echo e(rtrim(rtrim(number_format((float)$item->quantity, 2), '0'), '.')); ?></td>
                    <td class="right"><?php echo e(number_format((float)$item->unit_price, 2)); ?></td>
                    <td class="right"><?php echo e(number_format((float)$item->line_total, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </tbody>
    </table>

    <table class="totals">
        <tr><td>Subtotal</td><td class="right"><?php echo e(number_format((float)$facture->subtotal, 2)); ?></td></tr>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if((float)$facture->discount_amount > 0): ?><tr><td>Discount</td><td class="right">-<?php echo e(number_format((float)$facture->discount_amount, 2)); ?></td></tr><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <tr><td>Tax</td><td class="right"><?php echo e(number_format((float)$facture->tax_amount, 2)); ?></td></tr>
        <tr class="grand"><td>Total (<?php echo e($store->currency); ?>)</td><td class="right"><?php echo e(number_format((float)$facture->total_amount, 2)); ?></td></tr>
        <tr><td>Paid</td><td class="right"><?php echo e(number_format((float)$facture->amount_paid, 2)); ?></td></tr>
        <tr><td>Balance due</td><td class="right"><?php echo e(number_format($facture->amount_remaining, 2)); ?></td></tr>
    </table>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($facture->notes): ?><p class="muted"><?php echo e($facture->notes); ?></p><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

    <div class="footer">Generated <?php echo e(now()->format('Y-m-d H:i')); ?> · <?php echo e($facture->invoice_number); ?></div>
</body>
</html>
<?php /**PATH C:\Users\toshiba\Desktop\Work Laravel\claude\saas-commerce\resources\views\documents\facture.blade.php ENDPATH**/ ?>
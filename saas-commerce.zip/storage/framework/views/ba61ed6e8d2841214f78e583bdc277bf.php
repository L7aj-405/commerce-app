<?php
    /** @var \App\Models\Order $order */
    $currency = $order->store->currency ?? $order->currency ?? '$';
    $address  = data_get($order->platform_data, 'shipping.address_1')
        ?? data_get($order->platform_data, 'shipping.address');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        * { box-sizing: border-box; }
        body { font-family: dejavusansmono, monospace; font-size: 9pt; margin: 0; padding: 0; color: #000; }
        .center { text-align: center; }
        .right  { text-align: right; }
        .row    { width: 100%; }
        .row td { vertical-align: top; padding: 1px 0; font-size: 8.5pt; }
        .row td.r { text-align: right; }
        hr { border: 0; border-top: 1px dashed #000; margin: 4px 0; }
        h1 { font-size: 11pt; margin: 2px 0; }
        .muted { color: #444; font-size: 7.5pt; }
        .total { font-size: 10pt; font-weight: bold; }
        .tag { display: inline-block; border: 1px solid #000; padding: 0 3px; font-size: 7.5pt; }
    </style>
</head>
<body>

<div class="center">
    <h1><?php echo e($order->store->name ?? 'Store'); ?></h1>
    <div class="muted">Order <?php echo e($order->order_number); ?></div>
    <div class="muted"><?php echo e($order->created_at?->format('Y-m-d H:i')); ?></div>
    <div><span class="tag">ONLINE ORDER</span></div>
</div>

<hr>

<table class="row">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="2"><strong><?php echo e($item['description']); ?></strong></td>
        </tr>
        <tr>
            <td class="muted"><?php echo e($item['sku'] ?: '—'); ?> · <?php echo e((float) $item['quantity']); ?> × <?php echo e($currency); ?><?php echo e(number_format((float) $item['unit_price'], 2)); ?></td>
            <td class="r"><?php echo e($currency); ?><?php echo e(number_format((float) $item['line_total'], 2)); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</table>

<hr>

<table class="row">
    <tr>
        <td>Subtotal</td>
        <td class="r"><?php echo e($currency); ?><?php echo e(number_format((float) $totals['subtotal'], 2)); ?></td>
    </tr>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if((float) $totals['discount_amount'] > 0): ?>
        <tr>
            <td>Discount</td>
            <td class="r">−<?php echo e($currency); ?><?php echo e(number_format((float) $totals['discount_amount'], 2)); ?></td>
        </tr>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if((float) $totals['tax_amount'] > 0): ?>
        <tr>
            <td>Tax</td>
            <td class="r"><?php echo e($currency); ?><?php echo e(number_format((float) $totals['tax_amount'], 2)); ?></td>
        </tr>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <tr class="total">
        <td>TOTAL</td>
        <td class="r"><?php echo e($currency); ?><?php echo e(number_format((float) $totals['total_amount'], 2)); ?></td>
    </tr>
</table>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->customer_name || $order->customer_phone || $order->customer_email || $address): ?>
    <hr>
    <div class="muted">
        <div><strong>Deliver to</strong></div>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->customer_name): ?><div><?php echo e($order->customer_name); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->customer_phone): ?><div><?php echo e($order->customer_phone); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->customer_email): ?><div><?php echo e($order->customer_email); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($address): ?><div><?php echo e($address); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($order->notes): ?>
    <hr>
    <div class="muted"><?php echo e($order->notes); ?></div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<hr>

<div class="center muted">Thank you!</div>

</body>
</html>
<?php /**PATH C:\Users\toshiba\Desktop\Work Laravel\claude\saas-commerce\resources\views\documents\online-receipt.blade.php ENDPATH**/ ?>
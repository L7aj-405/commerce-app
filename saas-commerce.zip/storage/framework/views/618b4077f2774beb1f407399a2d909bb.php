<?php
    $store    = $facture->store;
    $currency = $store->currency ?? '';
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        * { box-sizing: border-box; }
        body { font-family: dejavusansmono, monospace; font-size: 9pt; margin: 0; padding: 0; color: #000; }
        .center { text-align: center; }
        .right  { text-align: right; }
        .row    { width: 100%; }
        .row td { vertical-align: top; padding: 1px 0; font-size: 8.5pt; }
        .row td.r { text-align: right; }
        hr { border: 0; border-top: 1px dashed #000; margin: 4px 0; }
        h1 { font-size: 11pt; margin: 2px 0; }
        .muted { color: #444; font-size: 7.5pt; }
        .total { font-size: 10pt; font-weight: bold; }
    </style>
</head>
<body>

<div class="center">
    <h1><?php echo e($store->name ?? 'Invoice'); ?></h1>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($store->address): ?><div class="muted"><?php echo e($store->address); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <div class="muted">Invoice <?php echo e($facture->invoice_number); ?></div>
    <div class="muted"><?php echo e(($facture->invoice_date ?? $facture->created_at)?->format('Y-m-d H:i')); ?></div>
    <div class="muted"><?php echo e(ucfirst($facture->status)); ?></div>
</div>

<hr>

<table class="row">
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $facture->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td colspan="2"><strong><?php echo e($item->description); ?></strong></td>
        </tr>
        <tr>
            <td class="muted"><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($item->sku): ?><?php echo e($item->sku); ?> · <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?><?php echo e(rtrim(rtrim(number_format((float) $item->quantity, 2), '0'), '.')); ?> × <?php echo e($currency); ?><?php echo e(number_format((float) $item->unit_price, 2)); ?></td>
            <td class="r"><?php echo e($currency); ?><?php echo e(number_format((float) $item->line_total, 2)); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</table>

<hr>

<table class="row">
    <tr>
        <td>Subtotal</td>
        <td class="r"><?php echo e($currency); ?><?php echo e(number_format((float) $facture->subtotal, 2)); ?></td>
    </tr>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if((float) $facture->discount_amount > 0): ?>
        <tr>
            <td>Discount</td>
            <td class="r">−<?php echo e($currency); ?><?php echo e(number_format((float) $facture->discount_amount, 2)); ?></td>
        </tr>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if((float) $facture->tax_amount > 0): ?>
        <tr>
            <td>Tax</td>
            <td class="r"><?php echo e($currency); ?><?php echo e(number_format((float) $facture->tax_amount, 2)); ?></td>
        </tr>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    <tr class="total">
        <td>TOTAL</td>
        <td class="r"><?php echo e($currency); ?><?php echo e(number_format((float) $facture->total_amount, 2)); ?></td>
    </tr>
</table>

<hr>

<table class="row">
    <tr>
        <td>Paid</td>
        <td class="r"><?php echo e($currency); ?><?php echo e(number_format((float) $facture->amount_paid, 2)); ?></td>
    </tr>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if((float) $facture->amount_remaining > 0): ?>
        <tr>
            <td>Balance due</td>
            <td class="r"><?php echo e($currency); ?><?php echo e(number_format((float) $facture->amount_remaining, 2)); ?></td>
        </tr>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</table>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($facture->customer_name || $facture->customer_phone || $facture->customer_email): ?>
    <hr>
    <div class="muted">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($facture->customer_name): ?><div><?php echo e($facture->customer_name); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($facture->customer_phone): ?><div><?php echo e($facture->customer_phone); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($facture->customer_email): ?><div><?php echo e($facture->customer_email); ?></div><?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($facture->notes): ?>
    <hr>
    <div class="muted"><?php echo e($facture->notes); ?></div>
<?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

<hr>

<div class="center muted">Thank you!</div>

</body>
</html>
<?php /**PATH C:\Users\toshiba\Desktop\Work Laravel\claude\saas-commerce\resources\views\documents\facture-receipt.blade.php ENDPATH**/ ?>